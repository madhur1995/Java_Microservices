package com.example.resturantSearchService.exception.service;

import com.example.resturantSearchService.exception.ResturantSearchServiceAppException;

public class ResturantSearchServiceException extends ResturantSearchServiceAppException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ResturantSearchServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResturantSearchServiceException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ResturantSearchServiceException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ResturantSearchServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ResturantSearchServiceException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	
}
